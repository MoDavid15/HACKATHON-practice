/*
Name: Ortiz, Celver Zitro H.
Block: H
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class NewTaskController implements Initializable {
    
    @FXML public ComboBox Projects, Importance, Month, Day, Start, End;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Projects.getItems().addAll("Project 1", "Project 2", "Project 3"); //to be changed depending on the projects
        Importance.getItems().addAll("Minor", "Major", "VIP");
        Month.getItems().addAll("January", "February", "March", "April", "May", "June", "July", "August", "September",
                            "October", "November", "December");
        Day.getItems().addAll(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
        Start.getItems().addAll("12:00 MN", "01:00 AM", "02:00 AM", "03:00 AM", "04:00 AM", "05:00 AM", "06:00 AM",
                            "07:00 AM", "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM", 
                            "12:00 NN", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM", "06:00 PM",
                            "07:00 PM", "08:00 PM", "09:00 PM", "10:00 PM", "11:00 PM"); 
        End.getItems().addAll("12:00 MN", "01:00 AM", "02:00 AM", "03:00 AM", "04:00 AM", "05:00 AM", "06:00 AM",
                            "07:00 AM", "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM", 
                            "12:00 NN", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM", "06:00 PM",
                            "07:00 PM", "08:00 PM", "09:00 PM", "10:00 PM", "11:00 PM"); 
        }
}    
