/*
Name: Ortiz, Celver Zitro H.
Block: H
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.shape.Circle;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class NewProjectController implements Initializable {

    @FXML private Circle red, orange, yellow, neon, green, cyan, blue, violet, brown, gray, pink, black;
    
    @FXML
	private void pickColor(MouseEvent event) {
            String id = ((Circle)event.getSource()).getId();
            
            red.setVisible(false);
            orange.setVisible(false);
            yellow.setVisible(false);
            neon.setVisible(false);
            green.setVisible(false);
            cyan.setVisible(false);
            blue.setVisible(false);
            violet.setVisible(false);
            brown.setVisible(false);
            gray.setVisible(false);
            pink.setVisible(false);
            black.setVisible(false);
            
            switch (id) {
                case "r":
                    red.setVisible(true);
                    break;
                case "o":
                    orange.setVisible(true); 
                    break;
                case "y":
                    yellow.setVisible(true);  
                    break;
                case "n":
                    neon.setVisible(true); 
                    break;
                case "g":
                    green.setVisible(true); 
                    break;
                case "c":
                    cyan.setVisible(true);  
                    break;
                case "b":
                    blue.setVisible(true);
                    break;
                case "v":
                    violet.setVisible(true); 
                    break;
                case "br":
                    brown.setVisible(true);  
                    break;
                case "gy":
                    gray.setVisible(true); 
                    break;
                case "p":
                    pink.setVisible(true); 
                    break;
                case "bk":
                    black.setVisible(true);  
                    break;    
            }
            
            
        }            
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
