/*
Name: Ortiz, Celver Zitro H.
Block: H
 */

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class ProjectsController implements Initializable {
        
    @FXML
    private void Calendar(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Calendar.fxml"));
	Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        thisStage.hide();
        thisStage.setScene(scene);
        thisStage.setResizable(false);
        thisStage.show();
    }
    
    @FXML
    private void Home (MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
	Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        thisStage.hide();
        thisStage.setScene(scene);
        thisStage.setResizable(false);
        thisStage.show();
    }
    
    @FXML
    private void ProjectSpecific (MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ProjectSpecific.fxml"));
	Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        thisStage.hide();
        thisStage.setScene(scene);
        thisStage.setResizable(false);
        thisStage.show();
    }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }

}
