/*
Name: Ortiz, Celver Zitro H.
Section: Tau
Date Started: 08/08/2021
Date Finished: 08/08/2021
 */

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Optional;
import java.util.ResourceBundle;

import classes.Date;
import classes.User;
import java.io.File;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import org.json.simple.*;
import org.json.simple.parser.*;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */

public class HomeController implements Initializable {

    // Some private variables
    private JSONObject JSON;
    private HashMap<String, Object> user;
    private JSONArray projects;

    // Pre configured elements
    @FXML private Text scheduleTitle;
    @FXML private Text date;

    @FXML private Text currentProjectName;
    @FXML private Text currentProjectDesc;
    @FXML private Text currentProjectStatus;

    // Buttons and sht
    @FXML Circle newTask;

    // Saving json file
    public void save() throws IOException {

        // Overwrite the original file with a save
        FileWriter filewriter = new FileWriter("./src/data/data.json"); /* YO CHANGE THIS FILE PATH TO SMTH LIKE "./data.json" */
        filewriter.write(JSON.toJSONString());
        filewriter.close();

        // Get the data-storing file
        FileReader filereader = null;
        this.JSON = null;

        // Retrieve the stored data
        JSONParser parser = new JSONParser();
      
        // Attempt to access the file
        try {
            filereader = new FileReader("./src/data/data.json");
            JSON = (JSONObject) (parser.parse(filereader));
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void Calendar(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Calendar.fxml"));
	Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        thisStage.hide();
        thisStage.setScene(scene);
        thisStage.setResizable(false);
        thisStage.show();
    }
    
    @FXML
    private void Projects(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Projects.fxml"));
	Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        thisStage.hide();
        thisStage.setScene(scene);
        thisStage.setResizable(false);
        thisStage.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // Retrieve the stored data
        JSONParser parser = new JSONParser();

        // Get the data-storing file
        FileReader filereader = null;
        this.JSON = new JSONObject();
        
        // Attempt to access the file
        try {
            filereader = new FileReader("./src/data/data.json");
            JSON = (JSONObject) (parser.parse(filereader));
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        
        // Access the data within the file
        user = (HashMap) ((JSONArray) JSON.get("users")).get(User.getActive());
        projects = ((JSONArray) user.get("projects"));

        // Set the preconfigured elements
        Date now = new Date();
        date.setText(now.getDateString());
        scheduleTitle.setText(user.get("name") + "'s Schedule");
        
        // Event listeners
        EventHandler<MouseEvent> newTaskEventHandler = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent e) {

                // Create a dialog to display warning
                TextInputDialog dialog = new TextInputDialog("Untitled");

                // The title and description and sht
                dialog.setTitle("New Project");
                dialog.setContentText("Please name the new project you are about to start.");
                Optional<String> result = dialog.showAndWait();

                if(result.isPresent()){

                    // Name of the project and date
                    String name = result.get();
                    JSONObject newProject = new JSONObject();
                    Date now = new Date();

                    // Put data into object
                    newProject.put("name", name);
                    newProject.put("desc", "A new project.");
                    newProject.put("date", now.getDateString());
                    newProject.put("tasks", new JSONArray());

                    // Append to object
                    projects.add(newProject);

                    // Save the data
                    try {
                        save();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        };

        newTask.addEventFilter(MouseEvent.MOUSE_CLICKED, newTaskEventHandler);

    }
}
