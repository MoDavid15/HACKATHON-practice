/*
Name: Ortiz, Celver Zitro H.
Block: H
 */

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class HomeController implements Initializable {

    @FXML private ScrollPane slide;
    @FXML private Region prev,next;
    
    @FXML
	private void previous(MouseEvent event) throws IOException {
          slide.setHvalue(0.00);
        }
     
    @FXML
	private void after(MouseEvent event) throws IOException {
          slide.setHvalue(1.00);
        }
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
