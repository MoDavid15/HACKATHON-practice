

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import javafx.scene.Parent;

public class main extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        
        // Load the stage and scene
        Parent root = FXMLLoader.load(getClass().getResource("main.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
	stage.setResizable(false);
        
//        FXMLLoader fxmlLoader = FXMLLoader.load(getClass().getResource("./tracker/main.fxml"));
        
//        Scene scene = new Scene(fxmlLoader.load());
//        stage.setScene(scene);
//        stage.show();
//        stage.setResizable(false);
    }

    public static void main(String[] args) {
        launch();
    }
}