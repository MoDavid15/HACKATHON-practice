//
// User class
//

package com.tracker.tracker.templates;

import com.tracker.tracker.templates.Date;

public class User {

    // Current active user
    private static int active = 0;

    // Currently viewed project
    private static int project = 0;

    // User properties
    private String name;
    private String image;
    private Date date;

    // Main constructor
    public User(String name, String image){

        this.name = name;
        this.image = image;
        this.date = new Date();
    }

    // Getters
    public static int getActive(){
        return active;
    }

    public static int getProject() {
        return project;
    }
}