//
//  Class for representing dates
//

package com.tracker.tracker.templates;

// Libs
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

// Class
public class Date {

    // Static constants
    private static int[] monthLengths = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    // Time properties
    private int minute;
    private int hour;

    // Date properties
    private int year;
    private int month;
    private int day;

    // Duration measured in seconds
    private int duration = 0;

    // Set default value of all properties
    private void Default(){

        // Define the current date and time for setting defaults
        LocalDateTime date = LocalDateTime.now();
        String date_now = date.toString().split("T")[0];
        String time_now = date.toString().split("T")[1];

        int year = Integer.parseInt(date_now.split("-")[0]);
        int month = Integer.parseInt(date_now.split("-")[1]);
        int day = Integer.parseInt(date_now.split("-")[2]);

        int hour = Integer.parseInt(time_now.split(":")[0]);
        int minute = (int)Double.parseDouble(time_now.split(":")[1]);

        // Set the properties to the values obtained above
        this.year = year;
        this.month = month;
        this.day = day;

        this.hour = hour;
        this.minute = minute;
    }

    // Constructors
    public Date(){
        Default();
    }

    public Date(int day){
        Default();

        this.day = day;
    }

    public Date(int day, int month){
        Default();

        this.day = day;
        this.month = month;
    }

    public Date(int day, int month, int year){
        Default();

        this.day = day;
        this.month = month;
        this.year = year;
    }

    public Date(int day, int month, int year, int hour, int minute){
        Default();

        this.day = day;
        this.month = month;
        this.year = year;

        this.hour = hour;
        this.minute = minute;
    }

    // Utility functions
    public int monthDays(int month){

        // Computes the number of days in a year before this month
        int daysBeforeMonth = 0;
        for(int i = 0; i < month; i++){
            daysBeforeMonth += monthLengths[i];
        }

        return daysBeforeMonth;
    }

    // Formatted string getters
    public String getDateString(){
        return this.year + "-" + this.month + "-" + this.day;
    }

    public String getTimeString(){
        return this.hour + ":" + this.minute;
    }

    public String getDateAndTimeString(){
        return getDateString() + "T" + getTimeString();
    }

    // Date, time or both values
    public int getDateValue(){
        return this.year * 365 + monthDays(this.month) + this.day;
    }

    public int getTimeValue(){
        return this.hour * 60 + this.minute;
    }

    public int getDateAndTimeValue(){
        return getDateValue() * 1440 + getTimeValue();
    }

    // Individual property getters
    public int getYear(){
        return this.year;
    }

    public int getMonth(){
        return this.month;
    }

    public int getDay(){
        return this.day;
    }

    public int getHour(){
        return this.hour;
    }

    public int getMinute(){
        return this.minute;
    }
}
