/*
Name: Ortiz, Celver Zitro H.
Block: H
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.ColumnConstraints;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class CalendarController implements Initializable {
    @FXML private ColumnConstraints cols;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }

}
