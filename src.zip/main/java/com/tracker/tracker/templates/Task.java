//
//  Class for representing tasks
//

package com.tracker.tracker.templates;

import java.util.Map;

public class Task {

    // Some constants
    private static Map<String, Integer> weightClasses = Map.of(
            "minor", 1,
            "major", 2,
            "VIP",   3
    );

    // Class properties
    private String name;
    private Project proj;
    private Date date;

    private String type;
    private int weight;
    private boolean done = false;

    // Constructor
    public Task(String name, Project project, String type){

        // Set the values of the properties
        this.name = name;
        this.proj = proj;
        this.type = type;

        this.weight = weightClasses.get(type);
        project.getTaskList().add(this);
    }

    // Getters
    public String getName(){
        return name;
    }

    public String getType(){
        return type;
    }

    public int getWeight(){
        return weight;
    }

    public boolean isDone(){
        return done;
    }

    // Setters
    public void setDone(boolean status){
        done = status;
    };
}