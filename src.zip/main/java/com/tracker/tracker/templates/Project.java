package com.tracker.tracker.templates;

import java.util.ArrayList;

public class Project {

    private String name, description;
    private int totTask, totDTask, taskbar;
    private ArrayList<Task> taskList = new ArrayList<>();
    private static ArrayList<Project> projectList = new ArrayList<>();

    public Project(String n, String d){
        this.name = n;
        this.description = d;
        this.totTask = 0;
        this.totDTask = 0;
        projectList.add(this);
    }

    // Getter functions
    public String getName(){
        return name;
    }

    public String getDesc(){
        return description;
    }

    public int getTotTask(){
        return totTask;
    }

    public int getTotDTask(){
        return totDTask;
    }

    public ArrayList<Task> getTaskList(){
        return taskList;
    }

    public static ArrayList<Project> getProjectList(){
        return projectList;
    }

    // Task related functions
    public void newTask(Task t){
        taskList.add(t);
        totTask += t.getWeight();
    }

    public void removeTask(Task t){
        taskList.remove(t);
        totTask -= t.getWeight();

        if(t.isDone()){
            totDTask--;
        }
    }

    public void doneTask(Task t){
        t.setDone(true);
        totDTask++;
    }

    public void taskbar(){
        taskbar = totDTask / totTask;
    }

    public int tasksWeight(){
        return totTask;
    }
}
