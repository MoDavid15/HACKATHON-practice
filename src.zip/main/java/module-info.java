module com.tracker.tracker {
    requires javafx.controls;
    requires javafx.fxml;
    requires json.simple;


    opens com.tracker.tracker to javafx.fxml;
    exports com.tracker.tracker;
}